import { NextResponse } from 'next/server';
import twilio from 'twilio';
import connectDB from '@/lib/db';
import User from '@/models/User';
import jwt from 'jsonwebtoken';

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const serviceSid = process.env.TWILIO_SERVICE_SID;

export async function POST(req) {
  try {
    const { phone, otp, name } = await req.json();

    if (!phone || !otp) {
      return NextResponse.json({ success: false, message: 'Phone and OTP required' }, { status: 400 });
    }

    // ✅ Step 1: Verify OTP with Twilio
    const verificationCheck = await client.verify
      .services(serviceSid)
      .verificationChecks.create({ to: phone, code: otp });

    if (verificationCheck.status !== 'approved') {
      return NextResponse.json({ success: false, message: 'Invalid OTP' }, { status: 400 });
    }

    // ✅ Step 2: Connect to DB and find/create user
    await connectDB();

    const email = phone.replace('+91', '') + '@voxindia.co';

    let user = await User.findOne({ phone });

    if (!user) {
      // Create new user with ObjectId
      user = await User.create({
        phone,
        name: name || '',
        email,
      });
    } else {
      // Update user if exists
      user.name = name || user.name;
      user.email = email;
      await user.save();
    }

    // ✅ Step 3: Create token with correct ObjectId
    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // ✅ Step 4: Return success
    return NextResponse.json({
      success: true,
      user,
      token,
    });

  } catch (error) {
    console.error('[Twilio VERIFY OTP Error]', error);
    return NextResponse.json({ success: false, message: error.message || 'OTP verification failed' }, { status: 500 });
  }
}
