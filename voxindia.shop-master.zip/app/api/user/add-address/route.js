// /app/api/add-address/route.js
import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Address from '@/models/Address';
import { verifyToken } from '@/lib/verifyToken';

export async function POST(req) {
  try {
    const decoded = verifyToken(req); // ✅ gets userId
    await connectDB();

    const body = await req.json();

    const newAddress = await Address.create({
      ...body,
      userId: decoded.userId, // ✅ include userId
    });

    return NextResponse.json({ success: true, address: newAddress });
  } catch (error) {
    console.error('Add address error:', error.message);
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 400 }
    );
  }
}
