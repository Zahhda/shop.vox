// app/api/user/route.js
import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import User from '@/models/User';
import axios from 'axios';
import { verifyToken } from '@/lib/verifyToken';

export async function GET(req) {
  try {
    const decoded = verifyToken(req);
    await connectDB();
    const user = await User.findById(decoded.userId);
    if (!user) return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });

    return NextResponse.json({ success: true, user });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message || 'Unauthorized' }, { status: 401 });
  }
}

export async function PUT(req) {
  try {
    const decoded = verifyToken(req);
    await connectDB();

    const body = await req.json();
    const { name, email } = body;

    const updatedUser = await User.findByIdAndUpdate(
      decoded.userId,
      { name, email },
      { new: true }
    );

    if (!updatedUser) return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });

    return NextResponse.json({ success: true, user: updatedUser });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message || 'Unauthorized' }, { status: 401 });
  }
}
